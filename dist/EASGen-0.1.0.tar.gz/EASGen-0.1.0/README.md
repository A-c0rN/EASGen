![EASGen](https://github.com/A-c0rN/EASGen/blob/main/doc/img/EASGen.png)

EASy EAS generation in Python